**To create custom metadata**

This example creates custom metadata for the specified document.

Command::

  aws workdocs create-custom-metadata --resource-id d90d93c1fe44bad0c8471e973ebaab339090401a95e777cffa58e977d2983b65 --custom-metadata KeyName1=example,KeyName2=example2

Output::

  None