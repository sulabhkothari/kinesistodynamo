**To disassociate a TagOption from a resource**

The following ``disassociate-tag-option-from-resource`` example disassociates the specified ``TagOption`` from the resource. ::

   aws servicecatalog disassociate-tag-option-from-resource \
        --resource-id port-2s6abcdq5wdh4 \
        --tag-option-id tag-p3abc2pkpz5qc 

This command produces no output.
